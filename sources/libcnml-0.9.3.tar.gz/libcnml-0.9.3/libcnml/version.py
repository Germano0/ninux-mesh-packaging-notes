__version__ = '0.9.3'
__author__ = 'Pablo Castellano <pablo@anche.no>'
__license__ = 'GPLv3+'
